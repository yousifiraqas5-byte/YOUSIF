import {
  saveShop,
  getShops,
  saveRegistration,
  getRegistrations,
  saveComment,
  getComments,
  getRatings,
  getAllComments,
  saveRating,
  getCurrentUid,
  saveRecommendation,
  getUserRating,
  setCommentLike,
  getAllCommentLikes,
  registerAccount,
  loginAccount,
  getCurrentUserInfo,
  logoutAccount,
  isCurrentUserAnonymous,
  getCurrentUserProfile,
  onAuthChange
} from "./firebase.js";

document.addEventListener('DOMContentLoaded', () => {
  // كان معرّف الفورم في الكود القديم "shopForm" بينما الفورم الفعلي في
  // index.html معرّفه "registrationForm" — هذا كان يمنع أي submit listener
  // من العمل إطلاقًا. تم التصحيح هنا.
  const form = document.getElementById("registrationForm");

  // ---------------------------------------------------------------------
  // أداة تنظيف النصوص لمنع XSS: أي بيانات قادمة من المستخدم (اسم محل،
  // تعليق، وصف...) يجب أن تمر من هنا قبل إدراجها داخل innerHTML.
  // ---------------------------------------------------------------------
  function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, (ch) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;"
    }[ch]));
  }

  // يتحقق أن الرابط يبدأ بـ http/https قبل استخدامه كـ href، لمنع حقن
  // روابط من نوع javascript: عبر حقل "الموقع على الخريطة".
  function isSafeUrl(url) {
    try {
      const u = new URL(String(url), window.location.href);
      return u.protocol === "http:" || u.protocol === "https:";
    } catch {
      return false;
    }
  }

  // يبقي فقط الأرقام و + في رقم الهاتف (يمنع حقن أي HTML/سكربت عبره
  // ويصلح استخدامه داخل روابط tel: وداخل onclick).
  function sanitizePhone(value) {
    return String(value ?? "").replace(/[^\d+]/g, "");
  }

  // ---------------------------------------------------------------------
  // تخزين مؤقت مشترك لإعجابات التعليقات: قبل كان كل استدعاء لـ loadComments
  // (أي كل محل) يجلب getAllCommentLikes()+getCurrentUid() من جديد، فمع N
  // محل صار عندنا N طلب شبكة متزامن لنفس البيانات تقريبًا، وهذا كان السبب
  // الرئيسي لتأخر ظهور التعليقات. الحين نجلبها مرة وحدة ونشارك النتيجة،
  // ونفرغ التخزين المؤقت فقط لما يصير تغيير فعلي (إعجاب جديد/تعليق جديد).
  // ---------------------------------------------------------------------
  let likesDataPromise = null;
  function invalidateLikesCache() {
    likesDataPromise = null;
  }
  function getLikesData() {
    if (!likesDataPromise) {
      likesDataPromise = Promise.all([getAllCommentLikes(), getCurrentUid()])
        .catch(() => [[], null]);
    }
    return likesDataPromise;
  }

  // شنو المحلات اللي انفتح لها "عرض التفاصيل" وصارت تعليقاتها تنحمّل فعلاً.
  // بدل ما نحمّل تعليقات كل المحلات دفعة وحدة عند فتح الصفحة (وين أغلبها
  // أصلاً مخفي جوه card-extra)، نحمّلها بس أول مرة ينفتح فيها التفصيل.
  const loadedCommentShops = new Set();

  function timeToMillis(v) {
    if (!v) return 0;
    if (typeof v.toMillis === "function") return v.toMillis();
    if (typeof v.seconds === "number") return v.seconds * 1000;
    if (v instanceof Date) return v.getTime();
    const n = Number(v);
    return Number.isFinite(n) ? n : 0;
  }

  function attachPhoneLongPress(root) {
    if (!root) return;
    root.querySelectorAll(".shop-phone").forEach(el => {
      let startX = 0, startY = 0, pressed = false, timer = null;
      const cancel = () => {
        pressed = false;
        if (timer) { clearTimeout(timer); timer = null; }
      };
      el.addEventListener("pointerdown", (e) => {
        startX = e.clientX; startY = e.clientY; pressed = true;
        timer = setTimeout(() => {
          timer = null;
          if (pressed) showPhoneActions(el.dataset.phone, e);
        }, 600);
      });
      el.addEventListener("pointermove", (e) => {
        if (pressed && (Math.abs(e.clientX - startX) > 12 || Math.abs(e.clientY - startY) > 12)) cancel();
      });
      el.addEventListener("pointerup", cancel);
      el.addEventListener("pointercancel", cancel);
      el.addEventListener("pointerleave", cancel);
      el.addEventListener("contextmenu", (e) => {
        e.preventDefault();
        cancel();
        showPhoneActions(el.dataset.phone, e);
      });
    });
  }

  function showPhoneActions(phone, e) {
    closePhoneActions();
    const safePhone = sanitizePhone(phone);
    const overlay = document.createElement("div");
    overlay.className = "phone-action-overlay";
    overlay.onclick = closePhoneActions;
    const panel = document.createElement("div");
    panel.className = "phone-action-panel";
    panel.innerHTML = `
      <div class="phone-action-title">📞 ${escapeHTML(safePhone)}</div>
      <button type="button" data-action="call">📞 اتصال</button>
      <button type="button" data-action="copy">📋 نسخ الرقم</button>
      <button type="button" class="phone-action-cancel" data-action="cancel">إلغاء</button>
    `;
    panel.querySelector('[data-action="call"]').addEventListener("click", () => {
      window.location.href = `tel:${safePhone}`;
    });
    panel.querySelector('[data-action="copy"]').addEventListener("click", () => {
      window.copyPhone(safePhone);
    });
    panel.querySelector('[data-action="cancel"]').addEventListener("click", closePhoneActions);
    const sheet = document.createElement("div");
    sheet.id = "phoneActionSheet";
    sheet.className = "phone-action-sheet";
    sheet.appendChild(overlay);
    sheet.appendChild(panel);
    document.body.appendChild(sheet);
  }

  window.closePhoneActions = function () {
    const sheet = document.getElementById("phoneActionSheet");
    if (sheet) sheet.remove();
  };

  window.copyPhone = async function (phone) {
    try {
      await navigator.clipboard.writeText(phone);
    } catch (err) {
      const ta = document.createElement("textarea");
      ta.value = phone;
      document.body.appendChild(ta);
      ta.select();
      try { document.execCommand("copy"); } catch (e2) {}
      document.body.removeChild(ta);
    }
    closePhoneActions();
    alert("✅ تم نسخ رقم الهاتف");
  };

  window.attachPhoneLongPress = attachPhoneLongPress;

  function starWidgetHTML(shopId) {
    const safeId = escapeHTML(shopId);
    const starList = [5, 4, 3, 2, 1].map(v =>
      `<span class="star" data-v="${v}" data-shop-id="${safeId}" data-filled="false">☆</span>`
    ).join("");

    return `
      <span class="shop-rating-top">
        <span class="star-widget" id="top-star-${safeId}">${starList}</span>
        <span class="rating-summary" id="top-rating-${safeId}">⭐ 0.0 (0 تقييم)</span>
      </span>
    `;
  }

  // يضبط شكل نجمة واحدة (مليانة ★ أو فارغة ☆) ويحفظ حالتها الحقيقية في
  // data-filled حتى يقدر hover يرجّعها لحالتها الصحيحة بعد ما يبعد الماوس،
  // بدل الاعتماد فقط على كلاس CSS قد ما يكون مفعّل شكل مختلف.
  function setStarFilled(starEl, filled) {
    starEl.dataset.filled = filled ? "true" : "false";
    starEl.textContent = filled ? "★" : "☆";
    starEl.classList.toggle("selected", filled);
  }

  // تفعيل نجوم التقييم عبر addEventListener بدل onclick/onmouseover المضمّنة
  // في HTML (أنظف وأكثر أمانًا، ويعمل بشكل صحيح مع معرّفات تحتوي رموزًا خاصة).
  function attachStarWidgetEvents(root) {
    if (!root) return;
    root.querySelectorAll(".star-widget").forEach(widget => {
      const stars = widget.querySelectorAll(".star");
      stars.forEach(star => {
        const shopId = star.dataset.shopId;
        const v = Number(star.dataset.v);
        star.addEventListener("click", () => window.rateShop(shopId, v));
        star.addEventListener("mouseover", () => {
          stars.forEach(s => {
            const isPreviewFilled = Number(s.dataset.v) <= v;
            s.textContent = isPreviewFilled ? "★" : "☆";
            s.classList.toggle("hover", isPreviewFilled);
          });
        });
        star.addEventListener("mouseout", () => {
          stars.forEach(s => {
            s.textContent = s.dataset.filled === "true" ? "★" : "☆";
            s.classList.remove("hover");
          });
        });
      });
    });
  }

  function renderReviewSection(shopId) {
    const safeId = escapeHTML(shopId);
    return `
      <hr>
      <div class="review-block">
        <h4>💬 التعليقات</h4>
        <div class="comments-list" id="comments-${safeId}">
          جارٍ تحميل التعليقات...
        </div>
        <div class="review-form" id="comment-form-${safeId}">
          <div class="comment-input-row">
            <textarea id="comment-${safeId}" placeholder="اكتب تعليقك..."></textarea>
            <button type="button" class="comment-btn" data-shop-id="${safeId}" aria-label="إرسال" title="إرسال">➤</button>
          </div>
        </div>
      </div>
    `;
  }

  function attachCommentButtons(root) {
    if (!root) return;
    root.querySelectorAll(".comment-btn").forEach(btn => {
      btn.addEventListener("click", () => window.sendComment(btn.dataset.shopId));
    });
  }

  function attachCardToggle(root) {
    if (!root) return;
    root.querySelectorAll(".card-toggle-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        const extra = btn.previousElementSibling;
        if (!extra || !extra.classList.contains("card-extra")) return;
        const open = extra.style.display !== "none";
        extra.style.display = open ? "none" : "block";
        btn.textContent = open ? "▼ عرض التفاصيل" : "▲ إخفاء التفاصيل";

        // نحمّل تعليقات هذا المحل بس أول مرة ينفتح فيها "عرض التفاصيل"،
        // مو لكل المحلات دفعة وحدة وقت تحميل الصفحة. هذا يخفف الزحمة على
        // الشبكة ويخلي التعليقات تطلع أسرع للمحل اللي فعلاً فتحته.
        const shopId = btn.dataset.shopId;
        if (!open && shopId && !loadedCommentShops.has(shopId)) {
          loadedCommentShops.add(shopId);
          loadComments(shopId);
        }
      });
    });
  }

  const registrationsContainer = document.getElementById('registrationsList');

  async function loadRegistrations() {
    if (!registrationsContainer) return;
    registrationsContainer.innerHTML = "جارٍ تحميل المحلات...";
    try {
      const regs = await getRegistrations();
      let allComments = [];
      try {
        allComments = await getAllComments();
      } catch (err) {
        // فشل جلب التعليقات لا يجب أن يمنع عرض قائمة المحلات نفسها.
        allComments = [];
      }
      const latestByShop = {};
      (Array.isArray(allComments) ? allComments : []).forEach(c => {
        const t = timeToMillis(c.createdAt);
        if (t > (latestByShop[c.shopId] || 0)) latestByShop[c.shopId] = t;
      });

      if (!Array.isArray(regs) || regs.length === 0) {
        registrationsContainer.innerHTML = "لا توجد محلات مسجلة حتى الآن";
        return;
      }

      regs.forEach(r => {
        r.__lastActivity = Math.max(timeToMillis(r.createdAt), latestByShop[r.id] || 0);
      });
      regs.sort((a, b) => (b.__lastActivity || 0) - (a.__lastActivity || 0));

      registrationsContainer.innerHTML = "";

      regs.forEach(r => {
        const typeLabel =
          r.regType === "seller" ? "🛒 بيع" :
          r.regType === "maintenance" ? "🔧 صيانة" :
          r.regType === "both" ? "🔧🛒 صيانة + بيع" : (r.regType || "");

        const specialties = Array.isArray(r.specialties) ? r.specialties.join("، ") : (r.specialty || "غير محدد");
        const safePhone = r.phone ? sanitizePhone(r.phone) : "";

        registrationsContainer.innerHTML += `
        <div class="registration-card">
          <h3>
            <span class="shop-name">${escapeHTML(r.name || r.shopName || "بدون اسم")}</span>
            ${starWidgetHTML(r.id)}
          </h3>
          <p><strong>الفئة:</strong> ${escapeHTML(typeLabel)}</p>
          <p><strong>التخصصات:</strong> ${escapeHTML(specialties)}</p>
          <p><strong>المحافظة:</strong> ${escapeHTML(r.city || "")}</p>
          <p><strong>المنطقة:</strong> ${escapeHTML(r.region || "")}</p>
          ${safePhone ? `<p><strong>📞 الهاتف:</strong> <span class="shop-phone" data-phone="${escapeHTML(safePhone)}">${escapeHTML(safePhone)}</span></p>` : ""}

          <div class="card-extra" style="display:none">
            ${r.landmark ? `<p><strong>📍 أقرب نقطة دالة / الشارع:</strong> ${escapeHTML(r.landmark)}</p>` : ""}
            <p><strong>أيام الدوام:</strong> ${escapeHTML(r.workDays || "غير محدد")}</p>
            <p><strong>أوقات الدوام:</strong> ${escapeHTML(r.workHours || "غير محدد")}</p>
            ${r.mapLocation && isSafeUrl(r.mapLocation) ? `<p><strong>🗺️ الموقع:</strong> <a href="${escapeHTML(r.mapLocation)}" target="_blank" rel="noopener noreferrer">فتح الموقع على الخريطة 📍</a></p>` : ""}
            ${r.description ? `<p><strong>📝 الوصف:</strong> ${escapeHTML(r.description)}</p>` : ""}
            ${renderReviewSection(r.id)}
          </div>

          <button type="button" class="card-toggle-btn" data-shop-id="${escapeHTML(r.id)}">▼ عرض التفاصيل</button>
        </div>`;
      });

      attachPhoneLongPress(registrationsContainer);
      attachStarWidgetEvents(registrationsContainer);
      attachCommentButtons(registrationsContainer);
      attachCardToggle(registrationsContainer);
    } catch (err) {
      registrationsContainer.innerHTML = `<div class="no-registrations">حدث خطأ أثناء جلب المحلات</div>`;
    }
  }

  window.loadRegistrations = loadRegistrations;

  // يجمع القيم المحدَّدة (checked) لمجموعة checkboxes حسب name، إن وُجدت.
  function getCheckedValues(name) {
    return Array.from(document.querySelectorAll(`input[name="${name}"]:checked`)).map(el => el.value);
  }

  if (form) {
    const regTypeSelect = document.getElementById("regType");
    const specialtyGroup = document.getElementById("specialtyGroup");
    const specialtyOptions = document.getElementById("specialtyOptions");

    const regMaintenance = [
      "فني تبريد وتكييف", "كهربائي سيارات", "فيتر (ميكانيكي)", "حداد صدر",
      "سمكري", "صباغ سيارات", "ميزان وبالنص", "تبديل زيت وفلاتر",
      "صيانة إيرباك", "صيانة ABS", "بريكات", "صيانة جير أوتوماتيك",
      "برمجة وفحص كمبيوتر", "بطاريات", "إطارات وبنجرجي", "تبديل زجاج",
      "صيانة رديتر", "عادم (إكزوزت)", "مفاتيح سيارات وبرمجة ريموت", "تلميع وحماية"
    ];
    const regSeller = [
      "قطع غيار", "إكسسوارات", "زيوت وفلاتر", "بطاريات",
      "إطارات", "جنوط", "إنارة", "أجهزة فحص"
    ];

    const fillSpecialties = () => {
      if (!regTypeSelect || !specialtyOptions) return;
      const type = regTypeSelect.value;
      specialtyOptions.innerHTML = "";
      const list = type === "maintenance" ? regMaintenance :
                    type === "seller" ? regSeller :
                    type === "both" ? [...regMaintenance, ...regSeller] : [];
      list.forEach(s => {
        const id = "spec_" + s.replace(/[^\w]/g, "_");
        specialtyOptions.insertAdjacentHTML("beforeend",
          `<label class="specialty-checkbox" for="${id}">
            <input type="checkbox" id="${id}" name="specialties" value="${s}">
            <span>${s}</span>
          </label>`);
      });
    };

    // دالة عامة لعرض ملخص الاختيارات أسفل كل قائمة
    function updateSelectionSummary(summaryEl, label, values) {
      if (!summaryEl) return;
      if (!values || values.length === 0) {
        summaryEl.style.display = "none";
        summaryEl.innerHTML = "";
        return;
      }
      summaryEl.style.display = "";
      summaryEl.innerHTML = `<strong>${label}:</strong> ${escapeHTML(values.join("، "))}`;
    }

    const specialtyContent = document.getElementById("specialtyContent");
    const specialtySummary = document.getElementById("specialtySummary");
    const specialtyToggleBtn = document.getElementById("specialtyToggle");

    function setupAccordionToggle(toggleId, contentEl) {
      const btn = document.getElementById(toggleId);
      if (!btn || !contentEl) return;
      btn.addEventListener("click", () => {
        const isOpen = contentEl.style.display !== "none";
        contentEl.style.display = isOpen ? "none" : "flex";
        btn.setAttribute("aria-expanded", String(!isOpen));
      });
    }

    setupAccordionToggle("specialtyToggle", specialtyContent);

    if (specialtyOptions) {
      specialtyOptions.addEventListener("change", (e) => {
        if (e.target && e.target.name === "specialties") {
          updateSelectionSummary(specialtySummary, "التخصصات المختارة", getCheckedValues("specialties"));
        }
      });
    }

    if (regTypeSelect && specialtyGroup) {
      regTypeSelect.addEventListener("change", () => {
        fillSpecialties();
        specialtyGroup.style.display = regTypeSelect.value ? "" : "none";
        // إغلاق القائمة دائماً بعد كل تغيير — لا تُفتح تلقائياً، وتصفير الملخص
        if (specialtyContent) specialtyContent.style.display = "none";
        if (specialtyToggleBtn) specialtyToggleBtn.setAttribute("aria-expanded", "false");
        updateSelectionSummary(specialtySummary, "التخصصات المختارة", []);
      });
    }

    // ---------------------------------------------------------------
    // منشأ / نوع (ماركة) / موديل / سنة السيارات — قوائم متسلسلة قابلة للطي
    // ---------------------------------------------------------------

    const CAR_BRANDS_BY_ORIGIN = {
      "أمريكي": [
        "فورد", "شفروليه", "جيب", "دودج", "كرايسلر", "جي إم سي", "كاديلاك",
        "لينكولن", "بيوك", "تسلا", "هامر"
      ],
      "أوروبي": [
        "مرسيدس", "بي إم دبليو", "أودي", "فولكس فاجن", "بورش", "بيجو",
        "رينو", "فيات", "فولفو", "لاند روفر", "سكودا", "سيات", "أوبل",
        "ميني", "جاكوار", "ألفا روميو", "سيتروين"
      ],
      "كوري": [
        "هيونداي", "كيا", "جينيسيس", "ساسانغ يونغ", "دايو"
      ],
      "ياباني": [
        "تويوتا", "هوندا", "نيسان", "مازدا", "ميتسوبيشي", "سوزوكي",
        "سوبارو", "لكزس", "إنفينيتي", "دايهاتسو", "إيسوزو"
      ],
      "صيني": [
        "جيلي", "MG", "شيري Chery", "هافال Haval", "بي واي دي BYD",
        "جاك JAC", "چانجان Changan", "جيتور Jetour", "دونغ فنغ Dongfeng",
        "فوتون Foton", "هونغتشي Hongqi", "أوموده Omoda", "زيكر Zeekr",
        "لينك آند كو Lynk & Co"
      ],
      "أخرى": ["أخرى"]
    };

    const CAR_MODELS_BY_BRAND = {
      "تويوتا": ["كورولا", "كامري", "لاندكروزر", "برادو", "يارس", "هايلكس", "راف 4", "أفالون", "فورتشنر", "هايس", "كورولا كروس", "سيكويا"],
      "هوندا": ["سيفيك", "أكورد", "سي آر في", "بايلوت", "إتش آر في", "أوديسي"],
      "نيسان": ["صني", "التيما", "باترول", "إكس تريل", "كيكس", "باثفايندر", "مكسيما", "نافارا"],
      "مازدا": ["مازدا 3", "مازدا 6", "CX-5", "CX-9", "CX-30"],
      "ميتسوبيشي": ["لانسر", "باجيرو", "أوتلاندر", "إكليبس كروس", "إل 200"],
      "سوزوكي": ["سويفت", "فيتارا", "بالينو", "جيمني"],
      "سوبارو": ["فورستر", "إمبريزا", "أوتباك", "XV"],
      "لكزس": ["ES", "LS", "LX", "RX", "GX", "NX", "IS"],
      "إنفينيتي": ["Q50", "QX60", "QX80"],

      "هيونداي": ["إلنترا", "سوناتا", "توسان", "سنتافي", "أكسنت", "فيلوستر", "أزيرا", "كريتا", "بالاسيد", "توسان ان لاين"],
      "كيا": ["سيراتو", "أوبتيما", "سبورتاج", "سورينتو", "بيكانتو", "كارنيفال", "ريو", "تيلورايد", "K5"],
      "جينيسيس": ["G70", "G80", "G90", "GV70", "GV80"],

      "فورد": ["فيوجن", "F-150", "إكسبلورر", "موستنج", "إيدج", "إكسبيديشن", "تورس", "برونكو"],
      "شفروليه": ["ماليبو", "كروز", "تاهو", "سيلفرادو", "كامارو", "إمبالا", "ترافيرس", "سوبربان"],
      "جيب": ["جراند شيروكي", "رانجلر", "كومباس", "شيروكي", "جراند شيروكي إل", "جلادييتور"],
      "دودج": ["تشارجر", "تشالنجر", "دورانجو", "جورني"],
      "جي إم سي": ["يوكن", "سييرا", "أكاديا", "تيرين"],
      "كاديلاك": ["إسكاليد", "CT5", "XT5", "XT6"],
      "كرايسلر": ["300", "باسيفيكا"],
      "لينكولن": ["نافيغيتور", "أفياتور", "كورسير"],

      "مرسيدس": ["الفئة C", "الفئة E", "الفئة S", "GLC", "GLE", "GLA", "GLS", "الفئة A", "G-Class (جي واغن)"],
      "بي إم دبليو": ["الفئة 3", "الفئة 5", "الفئة 7", "X1", "X3", "X5", "X6"],
      "أودي": ["A3", "A4", "A6", "A8", "Q3", "Q5", "Q7", "Q8"],
      "فولكس فاجن": ["باسات", "جيتا", "تيغوان", "طوارق", "بولو"],
      "بورش": ["كايين", "ماكان", "باناميرا", "911"],
      "لاند روفر": ["ديفندر", "ديسكفري", "رينج روفر", "رينج روفر سبورت", "إيفوك"],
      "بيجو": ["208", "308", "3008", "5008"],
      "رينو": ["داستر", "لوغان", "كوليوس", "ميغان"],
      "فيات": ["تيبو", "500"],
      "فولفو": ["XC60", "XC90", "S60", "S90"],

      "جيلي": ["إمغراند", "كولراي Coolray", "أزكارا Azkarra", "توغيلا"],
      "MG": ["MG5", "MG6", "ZS", "HS", "RX5"],
      "شيري Chery": ["تيغو 7", "تيغو 8", "أريزو 5"],
      "هافال Haval": ["H6", "جوليون Jolion", "H9"],
      "بي واي دي BYD": ["F3", "سونغ Song", "تانغ Tang", "هان Han"],
      "جاك JAC": ["S3", "S5", "JS4"],
      "چانجان Changan": ["CS35", "CS55", "إيدو Eado"]
    };

    const carOriginContent = document.getElementById("carOriginContent");
    const carOriginOptions = document.getElementById("carOriginOptions");
    const carOriginSummary = document.getElementById("carOriginSummary");
    const carOriginToggleBtn = document.getElementById("carOriginToggle");

    const carBrandGroup = document.getElementById("carBrandGroup");
    const carBrandContent = document.getElementById("carBrandContent");
    const carBrandOptions = document.getElementById("carBrandOptions");
    const carBrandSummary = document.getElementById("carBrandSummary");
    const carBrandToggleBtn = document.getElementById("carBrandToggle");

    const carModelGroup = document.getElementById("carModelGroup");
    const carModelContent = document.getElementById("carModelContent");
    const carModelOptions = document.getElementById("carModelOptions");
    const carModelSummary = document.getElementById("carModelSummary");
    const carModelToggleBtn = document.getElementById("carModelToggle");

    const carYearGroup = document.getElementById("carYearGroup");
    const carYearContent = document.getElementById("carYearContent");
    const carYearOptions = document.getElementById("carYearOptions");
    const carYearSummary = document.getElementById("carYearSummary");
    const carYearToggleBtn = document.getElementById("carYearToggle");

    // يملأ مجموعة checkboxes داخل حاوية معيّنة
    function fillCarCheckboxes(container, name, items) {
      if (!container) return;
      container.innerHTML = "";
      items.forEach(item => {
        const id = name + "_" + item.replace(/[^\wأ-ي]/g, "_");
        container.insertAdjacentHTML("beforeend",
          `<label class="specialty-checkbox" for="${id}">
            <input type="checkbox" id="${id}" name="${name}" value="${item}">
            <span>${item}</span>
          </label>`);
      });
    }

    // يطوي/يفرغ مجموعة كاملة (الزر + الخيارات + الملخص) ويعيدها لحالة مغلقة
    function collapseCarGroup(group, contentEl, optionsEl, toggleBtn, summaryEl) {
      if (optionsEl) optionsEl.innerHTML = "";
      if (contentEl) contentEl.style.display = "none";
      if (toggleBtn) toggleBtn.setAttribute("aria-expanded", "false");
      if (summaryEl) { summaryEl.style.display = "none"; summaryEl.innerHTML = ""; }
      if (group) group.style.display = "none";
    }

    // منشأ السيارات: قائمة ثابتة، تبقى مغلقة إلى أن يُضغط عليها
    setupAccordionToggle("carOriginToggle", carOriginContent);
    setupAccordionToggle("carBrandToggle", carBrandContent);
    setupAccordionToggle("carModelToggle", carModelContent);
    setupAccordionToggle("carYearToggle", carYearContent);

    function refreshCarYears() {
      collapseCarGroup(carYearGroup, carYearContent, carYearOptions, carYearToggleBtn, carYearSummary);
      const checkedModels = getCheckedValues("carModels");
      if (checkedModels.length === 0) return;
      const currentYear = new Date().getFullYear();
      const years = [];
      for (let y = currentYear + 1; y >= 1990; y--) years.push(String(y));
      fillCarCheckboxes(carYearOptions, "carYears", years);
      carYearGroup.style.display = "";
    }

    function refreshCarModels() {
      collapseCarGroup(carModelGroup, carModelContent, carModelOptions, carModelToggleBtn, carModelSummary);
      collapseCarGroup(carYearGroup, carYearContent, carYearOptions, carYearToggleBtn, carYearSummary);
      const checkedBrands = getCheckedValues("carBrands");
      if (checkedBrands.length === 0) return;
      const models = [...new Set(checkedBrands.flatMap(b => CAR_MODELS_BY_BRAND[b] || ["أخرى"]))];
      fillCarCheckboxes(carModelOptions, "carModels", models);
      carModelGroup.style.display = "";
    }

    function refreshCarBrands() {
      collapseCarGroup(carBrandGroup, carBrandContent, carBrandOptions, carBrandToggleBtn, carBrandSummary);
      collapseCarGroup(carModelGroup, carModelContent, carModelOptions, carModelToggleBtn, carModelSummary);
      collapseCarGroup(carYearGroup, carYearContent, carYearOptions, carYearToggleBtn, carYearSummary);
      const checkedOrigins = getCheckedValues("carOrigins");
      if (checkedOrigins.length === 0) return;
      const brands = [...new Set(checkedOrigins.flatMap(o => CAR_BRANDS_BY_ORIGIN[o] || []))];
      fillCarCheckboxes(carBrandOptions, "carBrands", brands);
      carBrandGroup.style.display = "";
    }

    if (carOriginOptions) {
      carOriginOptions.addEventListener("change", (e) => {
        if (e.target && e.target.name === "carOrigins") refreshCarBrands();
      });
    }
    if (carBrandOptions) {
      carBrandOptions.addEventListener("change", (e) => {
        if (e.target && e.target.name === "carBrands") refreshCarModels();
      });
    }
    if (carModelOptions) {
      carModelOptions.addEventListener("change", (e) => {
        if (e.target && e.target.name === "carModels") refreshCarYears();
      });
    }

    // أزرار "تم الاختيار" — تغلق القائمة وتعرض ملخص الاختيار أسفل الزر
    document.getElementById("carOriginDoneBtn")?.addEventListener("click", () => {
      if (carOriginContent) carOriginContent.style.display = "none";
      if (carOriginToggleBtn) carOriginToggleBtn.setAttribute("aria-expanded", "false");
      updateSelectionSummary(carOriginSummary, "المنشأ المختار", getCheckedValues("carOrigins"));
    });
    document.getElementById("carBrandDoneBtn")?.addEventListener("click", () => {
      if (carBrandContent) carBrandContent.style.display = "none";
      if (carBrandToggleBtn) carBrandToggleBtn.setAttribute("aria-expanded", "false");
      updateSelectionSummary(carBrandSummary, "نوع السيارة المختار", getCheckedValues("carBrands"));
    });
    document.getElementById("carModelDoneBtn")?.addEventListener("click", () => {
      if (carModelContent) carModelContent.style.display = "none";
      if (carModelToggleBtn) carModelToggleBtn.setAttribute("aria-expanded", "false");
      updateSelectionSummary(carModelSummary, "الموديل المختار", getCheckedValues("carModels"));
    });
    document.getElementById("carYearDoneBtn")?.addEventListener("click", () => {
      if (carYearContent) carYearContent.style.display = "none";
      if (carYearToggleBtn) carYearToggleBtn.setAttribute("aria-expanded", "false");
      updateSelectionSummary(carYearSummary, "سنة الصنع المختارة", getCheckedValues("carYears"));
    });

    function resetCarSelections() {
      collapseCarGroup(null, carOriginContent, carOriginOptions, carOriginToggleBtn, carOriginSummary);
      collapseCarGroup(carBrandGroup, carBrandContent, carBrandOptions, carBrandToggleBtn, carBrandSummary);
      collapseCarGroup(carModelGroup, carModelContent, carModelOptions, carModelToggleBtn, carModelSummary);
      collapseCarGroup(carYearGroup, carYearContent, carYearOptions, carYearToggleBtn, carYearSummary);
      // منشأ السيارات قائمة ثابتة لا تُفرَّغ محتوياتها (checkboxes ثابتة بالـ HTML)
      if (carOriginOptions) {
        carOriginOptions.querySelectorAll('input[name="carOrigins"]').forEach(cb => { cb.checked = false; });
      }
    }

    // ---------------------------------------------------------------
    // تنسيق رقم الهاتف أثناء الكتابة بالشكل: 07xx xxxxxxx (11 رقم)
    // ---------------------------------------------------------------
    const phoneInput = document.getElementById("phone");
    function formatPhoneDisplay(digits) {
      const d = digits.slice(0, 11);
      return d.length > 4 ? `${d.slice(0, 4)} ${d.slice(4)}` : d;
    }
    function isValidIraqiPhone(digits) {
      return digits.length === 11;
    }
    if (phoneInput) {
      phoneInput.setAttribute("maxlength", "12");
      phoneInput.setAttribute("placeholder", "07xx xxxxxxx");
      phoneInput.setAttribute("inputmode", "numeric");
      phoneInput.addEventListener("input", () => {
        const digitsOnly = phoneInput.value.replace(/\D/g, "").slice(0, 11);
        phoneInput.value = formatPhoneDisplay(digitsOnly);
      });
      phoneInput.addEventListener("blur", () => {
        const digitsOnly = phoneInput.value.replace(/\D/g, "");
        if (digitsOnly.length > 0 && !isValidIraqiPhone(digitsOnly)) {
          phoneInput.setCustomValidity("رقم الهاتف يجب أن يتكون من 11 رقم، مثال: 07xx xxxxxxx");
          phoneInput.reportValidity();
        } else {
          phoneInput.setCustomValidity("");
        }
      });
    }

    form.addEventListener("submit", async (e) => {
      e.preventDefault();

      const name = document.getElementById("name")?.value.trim() || "";
      const city = document.getElementById("city")?.value.trim() || "";
      const region = document.getElementById("region")?.value.trim() || "";

      if (!name || !city || !region) {
        alert("الرجاء تعبئة الحقول المطلوبة: اسم المحل، المحافظة، المنطقة");
        return;
      }

      const phoneDigits = (phoneInput?.value || "").replace(/\D/g, "");
      if (phoneDigits.length > 0 && !isValidIraqiPhone(phoneDigits)) {
        alert("رقم الهاتف يجب أن يتكون من 11 رقم، مثال: 07xx xxxxxxx");
        phoneInput?.focus();
        return;
      }

      const selectedSpecialties = getCheckedValues("specialties");
      if (selectedSpecialties.length === 0) {
        alert("الرجاء اختيار تخصص واحد على الأقل");
        return;
      }

      const data = {
        name,
        city,
        region,
        landmark: document.getElementById("landmark")?.value.trim() || "",
        phone: sanitizePhone(phoneDigits),
        regType: document.getElementById("regType")?.value || "",
        specialties: getCheckedValues("specialties"),
        workDays: document.getElementById("workDays")?.value.trim() || "",
        workHours: document.getElementById("workHours")?.value.trim() || "",
        mapLocation: document.getElementById("mapLocation")?.value.trim() || "",
        description: document.getElementById("description")?.value.trim() || "",
        carOrigins: getCheckedValues("carOrigins"),
        carBrands: getCheckedValues("carBrands"),
        carModels: getCheckedValues("carModels"),
        carYears: getCheckedValues("carYears")
      };

      try {
        const ok = await saveRegistration(data);
        if (ok) {
          alert("تم حفظ المحل");
          form.reset();
          if (specialtyGroup) specialtyGroup.style.display = "none";
          if (specialtyOptions) specialtyOptions.style.display = "none";
          document.getElementById("specialtyToggle")?.setAttribute("aria-expanded", "false");
          resetCarSelections();
          window.closeModal();
          loadRegistrations();
        } else {
          alert('حدث خطأ أثناء حفظ المحل');
        }
      } catch (err) {
        alert('حدث خطأ غير متوقع');
      }
    });
  }

  loadRegistrations();

  window.openModal = function () {
    const el = document.getElementById("registrationModal");
    if (el) el.classList.add("active");
  };

  window.openRecommendModal = function () {
    const el = document.getElementById("recommendModal");
    if (el) el.classList.add("active");
  };

  window.closeRecommendModal = function () {
    const el = document.getElementById("recommendModal");
    if (el) el.classList.remove("active");
  };

  const recommendForm = document.getElementById("recommendForm");
  if (recommendForm) {
    recommendForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const data = {
        name: document.getElementById("recName")?.value.trim() || "",
        phone: sanitizePhone(document.getElementById("recPhone")?.value || ""),
        city: document.getElementById("recCity")?.value.trim() || "",
        reason: document.getElementById("recReason")?.value.trim() || "",
        recommenderName: document.getElementById("recYourName")?.value.trim() || ""
      };
      try {
        const ok = await saveRecommendation(data);
        if (ok) {
          alert("شكرًا لك! تم إرسال ترشيحك وسنراجعه قريبًا 🙏");
          recommendForm.reset();
          window.closeRecommendModal();
        } else {
          alert("حدث خطأ أثناء إرسال الترشيح");
        }
      } catch (err) {
        alert("حدث خطأ غير متوقع");
      }
    });
  }

  window.sendComment = async function (shopId) {
    const comment = document.getElementById(`comment-${shopId}`)?.value.trim() || "";
    if (!comment) {
      alert("اكتب تعليقك أولاً");
      return;
    }

    const userInfo = await getCurrentUserInfo();
    let name = "";
    if (userInfo && !userInfo.isAnonymous) {
      name = userInfo.name || userInfo.email.split("@")[0];
    }

    if (!name) {
      const nameBox = document.getElementById(`cname-${shopId}`);
      name = nameBox?.value.trim() || "";
    }

    const ok = await saveComment({
      shopId,
      comment,
      name: name || "مستخدم"
    });

    if (!ok) {
      alert("حدث خطأ أثناء الحفظ");
      return;
    }

    const commentBox = document.getElementById(`comment-${shopId}`);
    if (commentBox) commentBox.value = "";
    await loadComments(shopId);
  };

  function attachCommentLikeButtons(root) {
    if (!root) return;
    root.querySelectorAll(".comment-like-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        window.toggleCommentLike(btn.dataset.commentId, btn.dataset.shopId);
      });
    });
  }

  window.toggleCommentLike = async function (commentId, shopId) {
    const btn = document.querySelector(`.comment-like-btn[data-comment-id="${commentId}"]`);
    const alreadyLiked = btn ? btn.classList.contains("liked") : false;
    const ok = await setCommentLike(commentId, !alreadyLiked);
    if (!ok) {
      alert("حدث خطأ أثناء تسجيل الإعجاب");
      return;
    }
    invalidateLikesCache();
    await loadComments(shopId);
  };

  window.rateShop = async function (shopId, value) {
    const widget = document.getElementById(`top-star-${shopId}`);
    const previous = widget && widget.dataset.userRating ? Number(widget.dataset.userRating) : null;
    const starsText = value === 1 ? 'نجمة' : 'نجوم';
    if (previous) {
      const ok = window.confirm(`أنت قيّمت هذا المحل مسبقاً بـ ${previous} ${previous === 1 ? 'نجمة' : 'نجوم'}.\nهل تريد تغيير تقييمك إلى ${value} ${starsText}؟`);
      if (!ok) return;
    }
    const result = await saveRating({ shopId, rating: value });
    if (!result) {
      alert("حدث خطأ أثناء حفظ التقييم");
      return;
    }
    await loadComments(shopId);
  };

  async function loadComments(shopId) {
    const ratingBadges = document.querySelectorAll(`[id="top-rating-${shopId}"]`);
    const starWidgets = document.querySelectorAll(`[id="top-star-${shopId}"]`);
    const boxes = document.querySelectorAll(`[id="comments-${shopId}"]`);
    const box = boxes[0];

    try {
      const ratings = await getRatings(shopId);
      const ratingsList = Array.isArray(ratings) ? ratings : [];
      const votes = ratingsList.length;
      const average = votes ? ratingsList.reduce((sum, c) => sum + (Number(c.rating) || 0), 0) / votes : 0;
      const summaryText = `⭐ ${average.toFixed(1)} (${votes} تقييم)`;

      if (starWidgets.length > 0) {
        const userRating = await getUserRating(shopId);
        starWidgets.forEach(widget => {
          if (userRating) {
            widget.querySelectorAll(".star").forEach(s => {
              const val = Number(s.dataset.v) || 0;
              setStarFilled(s, val <= userRating);
            });
            widget.classList.add("already-rated");
            widget.dataset.userRating = userRating;
            widget.title = `تقييمك الحالي: ${userRating} ${userRating === 1 ? 'نجمة' : 'نجوم'} (اضغط لتعديل)`;
          } else {
            const rounded = Math.round(average);
            widget.querySelectorAll(".star").forEach(s => {
              const val = Number(s.dataset.v) || 0;
              setStarFilled(s, val <= rounded);
            });
            widget.classList.remove("already-rated");
          }
        });

        if (ratingBadges.length > 0) {
          if (userRating) {
            const note = `⭐ تقييمك: ${userRating} ${userRating === 1 ? 'نجمة' : 'نجوم'}`;
            ratingBadges.forEach(b => { b.innerHTML = `${escapeHTML(summaryText)}<br><span class="my-rating-note">${escapeHTML(note)}</span>`; });
          } else {
            ratingBadges.forEach(b => { b.textContent = summaryText; });
          }
        }
      } else if (ratingBadges.length > 0) {
        ratingBadges.forEach(b => { b.textContent = summaryText; });
      }

      const comments = await getComments(shopId);
      const list = Array.isArray(comments) ? comments : [];
      if (box) {
        if (list.length === 0) {
          box.innerHTML = `<p class="no-comments">لا توجد تعليقات بعد، كن أول من يكتب تعليقًا</p>`;
        } else {
          // ترقيم مجهول لكل شخص (uid) حسب أول ظهور له زمنيًا، بحيث نفس
          // الشخص ياخذ نفس الرقم بكل تعليقاته على هذا المحل، شبيه بأسلوب
          // "مشارك مجهول #1" المستخدم بمجموعات فيسبوك.
          const chronological = [...list].sort((a, b) => timeToMillis(a.createdAt) - timeToMillis(b.createdAt));
          const anonNumberByKey = {};
          let nextAnonNumber = 1;
          chronological.forEach(c => {
            const key = c.uid || `__no_uid_${c.id}`;
            if (!(key in anonNumberByKey)) {
              anonNumberByKey[key] = nextAnonNumber++;
            }
          });
          const anonLabel = (c) => {
            if (c.name && c.name !== "مستخدم") {
              return c.name;
            }
            const key = c.uid || `__no_uid_${c.id}`;
            return `مشارك مجهول (${anonNumberByKey[key]})`;
          };

          // يجلب كل الإعجابات بطلب واحد ثم يحسب عدد إعجابات كل تعليق
          // وهل المستخدم الحالي معجب فيه، بدل استعلام منفصل لكل تعليق.
          let likesByComment = {};
          try {
            const [allLikes, myUid] = await getLikesData();
            (Array.isArray(allLikes) ? allLikes : []).forEach(l => {
              if (!likesByComment[l.commentId]) likesByComment[l.commentId] = { count: 0, likedByMe: false };
              likesByComment[l.commentId].count++;
              if (myUid && l.uid === myUid) likesByComment[l.commentId].likedByMe = true;
            });
          } catch (e) {
            likesByComment = {};
          }

          const renderOne = (c) => {
            const likeInfo = likesByComment[c.id] || { count: 0, likedByMe: false };
            const safeCommentId = escapeHTML(c.id);
            const safeShopId = escapeHTML(shopId);
            return `
            <div class="comment-item">
              <div class="comment-header">
                <span class="comment-name">${escapeHTML(anonLabel(c))}</span>
                <button type="button" class="comment-like-btn${likeInfo.likedByMe ? " liked" : ""}" data-comment-id="${safeCommentId}" data-shop-id="${safeShopId}" aria-pressed="${likeInfo.likedByMe ? "true" : "false"}" aria-label="إعجاب">
                  <svg class="like-icon" viewBox="0 0 24 24" width="15" height="15" aria-hidden="true"><path d="M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-1.91l-.01-.01L23 10z"/></svg>
                  <span class="like-count">${likeInfo.count}</span>
                </button>
              </div>
              ${c.comment ? `<p class="comment-text">${escapeHTML(c.comment)}</p>` : ""}
            </div>`;
          };
          const visible = list.slice(0, 2).map(renderOne).join("");
          const hidden = list.slice(2).map(renderOne).join("");
          const hiddenHtml = hidden ? `<div class="comments-hidden" style="display:none;">${hidden}</div><button type="button" class="show-more-comments">عرض المزيد (${list.length - 2}+)</button>` : "";
          box.innerHTML = `<div class="comments-visible">${visible}</div>${hiddenHtml}`;

          const moreBtn = box.querySelector(".show-more-comments");
          if (moreBtn) {
            moreBtn.addEventListener("click", () => {
              const hiddenBox = box.querySelector(".comments-hidden");
              if (hiddenBox) hiddenBox.style.display = "block";
              moreBtn.style.display = "none";
            });
          }

          attachCommentLikeButtons(box);
        }
      }
    } catch (err) {
      if (box) box.innerHTML = `<p class="no-comments">تعذّر تحميل التعليقات</p>`;
    }
  }

  window.openAsFullPage = function () {
    const homePage = document.querySelector(".container");
    const registrationsList = document.getElementById("registrationsList");
    if (!registrationsList) return;
    document.body.appendChild(registrationsList);
    if (homePage) homePage.style.display = "none";
    registrationsList.style.display = "block";
    registrationsList.style.minHeight = "100vh";
    registrationsList.style.padding = "20px";
    registrationsList.style.boxSizing = "border-box";

    let backButton = document.getElementById("registrationsBackButton");
    if (!backButton) {
      backButton = document.createElement("button");
      backButton.id = "registrationsBackButton";
      backButton.innerHTML = "⬅️ رجوع";
      backButton.style.cssText = "display:block;width:100%;max-width:390px;margin:0 auto 20px auto;padding:14px;border:none;border-radius:15px;font-size:17px;font-weight:bold;cursor:pointer;";
      backButton.onclick = function () {
        registrationsList.style.display = "none";
        if (homePage) {
          homePage.appendChild(registrationsList);
          homePage.style.display = "";
        }
        window.scrollTo({ top: 0, behavior: "smooth" });
      };
      registrationsList.prepend(backButton);
    } else {
      registrationsList.prepend(backButton);
    }
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

window.showCategoryRegistrations = async function (type, specialty) {
    const container = document.getElementById("registrationsList");
    if (!container) return;
    container.innerHTML = "🔍 جارٍ التحميل...";

    if (typeof window.openAsFullPage === "function") window.openAsFullPage();

    try {
      const regs = await getRegistrations();
      const results = regs.filter(r => {
        if (specialty === "__all__") return r.regType === type || r.regType === "both";
        if (r.regType !== type && r.regType !== "both") return false;
        if (Array.isArray(r.specialties)) return r.specialties.includes(specialty);
        if (Array.isArray(r.specialty)) return r.specialty.includes(specialty);
        return String(r.specialty || "").trim() === String(specialty || "").trim();
      });

      if (results.length === 0) {
        container.innerHTML = `<div class="no-registrations">لا توجد محلات مسجلة ضمن: <strong>${specialty === "__all__" ? "هذا القسم" : specialty}</strong></div>`;
        if (typeof window.openAsFullPage === "function") window.openAsFullPage();
        return;
      }

      container.innerHTML = "";
      results.forEach(r => {
        const typeLabel =
          r.regType === "seller" ? "🛒 بيع" :
          r.regType === "maintenance" ? "🔧 صيانة" :
          r.regType === "both" ? "🔧🛒 صيانة + بيع" : (r.regType || "");
        const specialties = Array.isArray(r.specialties) ? r.specialties.join("، ") : (r.specialty || "غير محدد");

        const safePhone = r.phone ? sanitizePhone(r.phone) : "";

        container.innerHTML += `
        <div class="registration-card">
          <h3>
            <span class="shop-name">${escapeHTML(r.name || r.shopName || "بدون اسم")}</span>
            ${starWidgetHTML(r.id)}
          </h3>
          <p><strong>الفئة:</strong> ${escapeHTML(typeLabel)}</p>
          <p><strong>التخصصات:</strong> ${escapeHTML(specialties)}</p>
          <p><strong>المحافظة:</strong> ${escapeHTML(r.city || "")}</p>
          <p><strong>المنطقة:</strong> ${escapeHTML(r.region || "")}</p>
          ${safePhone ? `<p><strong>📞 الهاتف:</strong> <span class="shop-phone" data-phone="${escapeHTML(safePhone)}">${escapeHTML(safePhone)}</span></p>` : ""}
          <div class="card-extra" style="display:none">
            ${r.landmark ? `<p><strong>📍 أقرب نقطة دالة / الشارع:</strong> ${escapeHTML(r.landmark)}</p>` : ""}
            ${r.mapLocation && isSafeUrl(r.mapLocation) ? `<p><strong>🗺️ الموقع:</strong> <a href="${escapeHTML(r.mapLocation)}" target="_blank" rel="noopener noreferrer">فتح الموقع على الخريطة 📍</a></p>` : ""}
            ${renderReviewSection(r.id)}
          </div>
          <button type="button" class="card-toggle-btn" data-shop-id="${escapeHTML(r.id)}">▼ عرض التفاصيل</button>
        </div>`;
      });

      attachPhoneLongPress(container);
      attachStarWidgetEvents(container);
      attachCommentButtons(container);
      attachCardToggle(container);
      if (typeof window.openAsFullPage === "function") window.openAsFullPage();
    } catch (err) {
      container.innerHTML = `<div class="no-registrations">حدث خطأ أثناء جلب المحلات</div>`;
    }
  };

  window.openRegistrationsPage = function () {
    loadRegistrations().then(() => window.openAsFullPage && window.openAsFullPage());
  };

window.openCategory = async function (type) {
    const title = document.querySelector(".section-title");
    const grid = document.querySelector(".category-grid");
    const backButton = document.getElementById("backToHome");
    if (!title || !grid) {
      console.error("category elements not found");
      return;
    }

    const maintenanceSpecialties = [
      "فني تبريد وتكييف",
      "كهربائي سيارات",
      "فيتر (ميكانيكي)",
      "حداد صدر",
      "سمكري",
      "صباغ سيارات",
      "ميزان وبالنص",
      "تبديل زيت وفلاتر",
      "صيانة إيرباك",
      "صيانة ABS",
      "بريكات (دسكات، فلنجات، سفايف)",
      "صيانة جير أوتوماتيك",
      "برمجة وفحص كمبيوتر",
      "بطاريات",
      "إطارات وبنجرجي",
      "تبديل زجاج",
      "صيانة رديتر",
      "عادم (إكزوزت)",
      "مفاتيح سيارات وبرمجة ريموت",
      "تلميع وحماية"
    ];
    const sellerSpecialties = [
      "قطع غيار",
      "إكسسوارات",
      "زيوت وفلاتر",
      "بطاريات",
      "إطارات",
      "جنوط",
      "إنارة",
      "أجهزة فحص"
    ];

    if (backButton) {
      backButton.style.display = "block";
      backButton.onclick = function () {
        title.textContent = "الأقسام";
        grid.innerHTML = `
      <div class="category-tile" onclick="openCategory('maintenance')">
        <div class="category-icon maintenance-icon">🔧</div>
        <h3>الصيانة</h3>
        <p>خدمات الصيانة والإصلاح</p>
      </div>
      <div class="category-tile" onclick="openCategory('seller')">
        <div class="category-icon sales-icon">🛒</div>
        <h3>المبيعات</h3>
        <p>المحلات والبائعين</p>
      </div>`;
        grid.classList.remove("specialty-list");
        backButton.style.display = "none";
        window.scrollTo({ top: 0, behavior: "smooth" });
      };
    }

    const specialties = type === "maintenance" ? maintenanceSpecialties :
                       type === "seller" ? sellerSpecialties : [];

    let allRegs = [];
    try {
      allRegs = await getRegistrations();
    } catch (e) { allRegs = []; }

    const countFor = (s) => allRegs.filter(r =>
      (r.regType === type || r.regType === "both") &&
      (Array.isArray(r.specialties) ? r.specialties.includes(s) :
       Array.isArray(r.specialty) ? r.specialty.includes(s) :
       String(r.specialty || "").trim() === s)
    ).length;

    const totalCount = allRegs.filter(r => r.regType === type || r.regType === "both").length;

    title.textContent = type === "maintenance" ? "🔧 خدمات الصيانة" : "🛒 فئات المبيعات";
    grid.classList.add("specialty-list");

    const allBtn = `<div class="specialty-row" onclick="showCategoryRegistrations('${type}', '__all__')">
        <span class="specialty-icon">📋</span>
        <span class="specialty-name" style="font-weight:bold">عرض جميع المحلات</span>
        <span class="specialty-count">${totalCount}</span>
        <span class="specialty-arrow">‹</span>
      </div>`;

    grid.innerHTML = allBtn + specialties.map(s => {
      const c = countFor(s);
      return `<div class="specialty-row" onclick="showCategoryRegistrations('${type}', '${s}')">
        <span class="specialty-icon">${type === "maintenance" ? "🔧" : "🛒"}</span>
        <span class="specialty-name">${s}</span>
        <span class="specialty-count">${c}</span>
        <span class="specialty-arrow">‹</span>
      </div>`;
    }).join("");

    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  window.closeModal = function () {
    const el = document.getElementById("registrationModal");
    if (el) el.classList.remove("active");
  };

  // -----------------------------------------------------------------
  // القائمة الجانبية: لم تكن مربوطة بأي JavaScript سابقًا (الأزرار كانت
  // تستدعي دوال غير موجودة أصلًا مثل goToHome/goToComplaints...).
  // -----------------------------------------------------------------
  const sideMenu = document.getElementById("sideMenu");
  const menuButton = document.getElementById("menuButton");
  const menuClose = document.getElementById("menuClose");
  const menuOverlay = document.getElementById("menuOverlay");

  function openSideMenu() {
    if (sideMenu) sideMenu.classList.add("active");
    if (menuOverlay) menuOverlay.classList.add("active");
  }

  function closeSideMenu() {
    if (sideMenu) sideMenu.classList.remove("active");
    if (menuOverlay) menuOverlay.classList.remove("active");
  }

  if (menuButton) menuButton.addEventListener("click", openSideMenu);
  if (menuClose) menuClose.addEventListener("click", closeSideMenu);
  if (menuOverlay) menuOverlay.addEventListener("click", closeSideMenu);

  window.goToHome = function () {
    closeSideMenu();
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // الصفحات التالية (الشكاوى / من نحن / اتصل بنا) غير موجودة بعد في
  // المشروع، فتم وضع دوال placeholder آمنة بدل الأخطاء السابقة (كانت هذه
  // الدوال غير معرّفة إطلاقًا وتسبب ReferenceError). تسجيل الدخول له تطبيق
  // فعلي الآن أدناه (openAuthModal / updateAuthUI).
  window.goToComplaints = function () {
    closeSideMenu();
    alert("صفحة الشكاوي قيد الإعداد حاليًا");
  };

  window.goToAbout = function () {
    closeSideMenu();
    alert("صفحة \"من نحن\" قيد الإعداد حاليًا");
  };

  window.goToContact = function () {
    closeSideMenu();
    alert("صفحة \"اتصل بنا\" قيد الإعداد حاليًا");
  };

  // -----------------------------------------------------------------
  // تسجيل الدخول / إنشاء حساب — منفصل تمامًا عن نموذج تسجيل المحل.
  // -----------------------------------------------------------------
  function translateAuthError(code) {
    const map = {
      "auth/email-already-in-use": "هذا البريد أو الرقم مسجّل مسبقًا، جرب تسجيل الدخول بدلاً من ذلك",
      "auth/invalid-email": "صيغة البريد أو رقم الهاتف غير صحيحة",
      "auth/weak-password": "كلمة المرور ضعيفة، يجب أن تكون 6 أحرف على الأقل",
      "auth/wrong-password": "كلمة المرور غير صحيحة",
      "auth/user-not-found": "لا يوجد حساب بهذا البريد أو الرقم",
      "auth/invalid-credential": "البريد/الرقم أو كلمة المرور غير صحيحة",
      "auth/too-many-requests": "محاولات كثيرة، حاول لاحقًا",
      "auth/operation-not-allowed": "تسجيل الدخول بالبريد/كلمة المرور غير مفعّل حاليًا من إعدادات المشروع",
      "auth/network-request-failed": "تعذّر الاتصال بالخادم، تأكد من اتصالك بالإنترنت"
    };
    return map[code] || `حدث خطأ غير متوقع (${code || "غير معروف"}), حاول مرة أخرى`;
  }

  const authModal = document.getElementById("authModal");
  const loginForm = document.getElementById("loginForm");
  const signupForm = document.getElementById("signupForm");
  const loginError = document.getElementById("loginError");
  const signupError = document.getElementById("signupError");
  const authModalTitle = document.getElementById("authModalTitle");
  const switchToSignup = document.getElementById("switchToSignup");
  const switchToLogin = document.getElementById("switchToLogin");
  const menuLoginItem = document.getElementById("menuLoginItem");
  const menuUserName = document.getElementById("menuUserName");
  const profileBtn = document.getElementById("profileBtn");
  const profileDropdown = document.getElementById("profileDropdown");
  const profileDropdownName = document.getElementById("profileDropdownName");
  const profileDropdownAuthBtn = document.getElementById("profileDropdownAuthBtn");

  // يحسب موقع القائمة المنسدلة حسب مكان أيقونة الحساب الفعلي على الشاشة
  // (بدل تخمين يمين/يسار)، عشان تضل داخل الشاشة بأي اتجاه (RTL/LTR).
  function positionProfileDropdown() {
    if (!profileBtn || !profileDropdown) return;
    const rect = profileBtn.getBoundingClientRect();
    const dropdownWidth = profileDropdown.offsetWidth || 190;
    let left = rect.right - dropdownWidth;
    left = Math.max(8, Math.min(left, window.innerWidth - dropdownWidth - 8));
    profileDropdown.style.top = `${rect.bottom + 8}px`;
    profileDropdown.style.left = `${left}px`;
  }

  function closeProfileDropdown() {
    if (!profileDropdown) return;
    profileDropdown.style.display = "none";
    if (profileBtn) profileBtn.setAttribute("aria-expanded", "false");
  }

  function toggleProfileDropdown() {
    if (!profileDropdown) return;
    const isOpen = profileDropdown.style.display !== "none";
    if (isOpen) {
      closeProfileDropdown();
      return;
    }
    profileDropdown.style.display = "block";
    if (profileBtn) profileBtn.setAttribute("aria-expanded", "true");
    positionProfileDropdown();
  }

  if (profileBtn) {
    profileBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      toggleProfileDropdown();
    });
  }

  document.addEventListener("click", (e) => {
    if (!profileDropdown || profileDropdown.style.display === "none") return;
    if (profileDropdown.contains(e.target) || (profileBtn && profileBtn.contains(e.target))) return;
    closeProfileDropdown();
  });

  window.addEventListener("resize", () => {
    if (profileDropdown && profileDropdown.style.display !== "none") positionProfileDropdown();
  });

  window.openAuthModal = function () {
    closeSideMenu();
    if (authModal) authModal.classList.add("active");
  };

  window.closeAuthModal = function () {
    if (authModal) authModal.classList.remove("active");
    if (loginError) loginError.style.display = "none";
    if (signupError) signupError.style.display = "none";
  };

  window.toggleAuthMode = function (mode) {
    const showSignup = mode === "signup";
    if (loginForm) loginForm.style.display = showSignup ? "none" : "";
    if (signupForm) signupForm.style.display = showSignup ? "" : "none";
    if (switchToSignup) switchToSignup.style.display = showSignup ? "none" : "";
    if (switchToLogin) switchToLogin.style.display = showSignup ? "" : "none";
    if (authModalTitle) authModalTitle.textContent = showSignup ? "🆕 إنشاء حساب" : "🔐 تسجيل الدخول";
    if (loginError) loginError.style.display = "none";
    if (signupError) signupError.style.display = "none";
  };

  async function updateAuthUI() {
    if (!menuLoginItem) return;
    const anonymous = isCurrentUserAnonymous();
    if (anonymous) {
      menuLoginItem.textContent = "🔐 تسجيل الدخول";
      menuLoginItem.classList.remove("logged-in");
      menuLoginItem.onclick = window.openAuthModal;
      if (menuUserName) {
        menuUserName.style.display = "none";
        menuUserName.textContent = "";
      }
      if (profileDropdownName) {
        profileDropdownName.style.display = "none";
        profileDropdownName.textContent = "";
      }
      if (profileDropdownAuthBtn) {
        profileDropdownAuthBtn.textContent = "🔐 تسجيل الدخول";
        profileDropdownAuthBtn.onclick = () => {
          closeProfileDropdown();
          window.openAuthModal();
        };
      }
      return;
    }
    const profile = await getCurrentUserProfile();
    const displayName = profile ? `${profile.firstName || ""} ${profile.lastName || ""}`.trim() : "";
    // الاسم يظهر بأعلى القائمة، وزر الخروج يضل بسيط بدون تكرار الاسم بيه.
    if (menuUserName) {
      if (displayName) {
        menuUserName.textContent = `👤 ${displayName}`;
        menuUserName.style.display = "";
      } else {
        menuUserName.style.display = "none";
        menuUserName.textContent = "";
      }
    }
    menuLoginItem.textContent = "🚪 تسجيل الخروج";
    menuLoginItem.classList.add("logged-in");
    menuLoginItem.onclick = window.logoutAccountUI;

    if (profileDropdownName) {
      if (displayName) {
        profileDropdownName.textContent = `👤 ${displayName}`;
        profileDropdownName.style.display = "";
      } else {
        profileDropdownName.style.display = "none";
        profileDropdownName.textContent = "";
      }
    }
    if (profileDropdownAuthBtn) {
      profileDropdownAuthBtn.textContent = "🚪 تسجيل الخروج";
      profileDropdownAuthBtn.onclick = () => {
        closeProfileDropdown();
        window.logoutAccountUI();
      };
    }
  }

  window.logoutAccountUI = async function () {
    closeSideMenu();
    await logoutAccount();
    await updateAuthUI();
  };

  if (loginForm) {
    loginForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      if (loginError) loginError.style.display = "none";
      const identifier = document.getElementById("loginIdentifier")?.value.trim() || "";
      const password = document.getElementById("loginPassword")?.value || "";
      if (!identifier || !password) return;
      const result = await loginAccount({ identifier, password });
      if (result.ok) {
        loginForm.reset();
        window.closeAuthModal();
        await updateAuthUI();
      } else if (loginError) {
        loginError.textContent = translateAuthError(result.code);
        loginError.style.display = "block";
      }
    });
  }

  if (signupForm) {
    signupForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      if (signupError) signupError.style.display = "none";
      const firstName = document.getElementById("signupFirstName")?.value.trim() || "";
      const lastName = document.getElementById("signupLastName")?.value.trim() || "";
      const identifier = document.getElementById("signupIdentifier")?.value.trim() || "";
      const password = document.getElementById("signupPassword")?.value || "";
      if (!firstName || !lastName || !identifier || !password) return;
      if (password.length < 6) {
        if (signupError) {
          signupError.textContent = "كلمة المرور يجب أن تكون 6 أحرف على الأقل";
          signupError.style.display = "block";
        }
        return;
      }
      const result = await registerAccount({ firstName, lastName, identifier, password });
      if (result.ok) {
        signupForm.reset();
        window.closeAuthModal();
        await updateAuthUI();
        alert("✅ تم التسجيل بنجاح");
      } else if (signupError) {
        signupError.textContent = translateAuthError(result.code);
        signupError.style.display = "block";
      }
    });
  }

  onAuthChange(() => { updateAuthUI(); });

  // ربط أزرار الأقسام الرئيسية بدون onclick مضمّن في HTML.
  document.querySelectorAll('[data-category]').forEach(el => {
    el.addEventListener("click", () => window.openCategory(el.dataset.category));
  });
});
